Cara Pakai : 
<br>
1.copy env.example ke env
<br>
2.buat db connect di env
<br>
3.jalankan composer install
<br>
4.jalankan npm install && npm run dev (kalau gak bisa satu satu saja)
<br>
5.jalankan php artisan migrate
<br>
6.jalankan php artisan storage:link
<br>
7.jalankan php artisan db:seed
<br>

8.php artisan serve

<br>
*catatan
Pastikan insert dulu beberapa concert(konser) untuk memunculkan menu di landing page agar bisa melakukan booking
pastikan jumlah tiket lebih dari 0 , kalo 0 sold out gabisa booking


Akun admin :

admin@concert.com
secret

Selamat Mencoba
